import 'package:emart_seller/const/const.dart';

const profileIconsList = [icShopSettings, icChat, icAccount];
const profileIconsTitle = [icShopSettings]; //messages, logout];

const popumMenuTitles = [featured, edit, remove];
const popupMenuIcons = [Icons.featured_play_list, Icons.edit, Icons.delete];

const profileButtonsTitles = [shopSettings, messages];
const profileButtonsIcons = [Icons.settings, Icons.chat];
