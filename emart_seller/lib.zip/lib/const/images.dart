const icLogo = "assets/icons/logo.png";
const icAccount = "assets/icons/account.png";
const icAdd = "assets/icons/add.png";
const icChat = "assets/icons/chat.png";
const icGeneralSettings = "assets/icons/general_setting.png";
const icOrders = "assets/icons/orders.png";
const icProducts = "assets/icons/products.png";
const icProfile = "assets/icons/profile.png";
const icShopSettings = "assets/icons/shop_setting.png";
const icStar = "assets/icons/star.png";
const icVerify = "assets/icons/verify.png";
const imgProduct = "assets/product.jpg";



