import 'package:get/get.dart';

class HomeController extends GetxController{
  var navIndex = 0.obs;
}

